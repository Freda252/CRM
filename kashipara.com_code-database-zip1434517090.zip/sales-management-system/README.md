# sales-management-system
(python initial level project) Tkinter python with database conectivity.
